@echo off
cd /d "%~dp0"
start "" "%~dp0demo-a\index.html"
